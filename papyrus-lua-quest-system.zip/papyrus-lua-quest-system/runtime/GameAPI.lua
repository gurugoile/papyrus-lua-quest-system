-- Game engine API abstraction
local GameAPI = {}
return GameAPI
