-- Dialog tree system
local DialogTree = {}
return DialogTree
