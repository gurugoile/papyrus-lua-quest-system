-- Quest base module
local Quest = {}
return Quest
