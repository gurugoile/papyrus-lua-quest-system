-- Actor behavior
local Actor = {}
return Actor
